import { Component, OnInit, Input } from '@angular/core';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  @Input('userinfo') userObj: User;
  userDeatil:User;
  editUserFlag:boolean=true;
  updateUserFlag:boolean=false;

  constructor() { 

  }

  ngOnInit() {
    this.userDeatil= {
      firstName:this.userObj.firstName,
      lastName:this.userObj.lastName,
      userId:this.userObj.userId,
      employeeId:this.userObj.employeeId
    }

  }

}
