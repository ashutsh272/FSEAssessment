export class Task {
    taskId: string ;
    task: string ;
    startDate:string;
    endDate: string ;
    priority: number=0;
    userId: string;
    userEId:string;
    parentTaskId:string;
    parentTask:string;
    status: string;
    parentTaskEnabled:boolean=false;
    projectId:string;
    projectName:string;
    constructor() { 
    }
}
	