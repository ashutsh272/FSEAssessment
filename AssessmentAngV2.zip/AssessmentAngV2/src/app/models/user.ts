export class User {
    userId: string ;
    firstName: string = '';
    lastName: string = '';
    employeeId: string = '';

    constructor() { 

    }
}
