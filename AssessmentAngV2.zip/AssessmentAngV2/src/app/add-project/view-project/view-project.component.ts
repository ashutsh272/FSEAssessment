import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Project } from 'src/app/models/project';

@Component({
  selector: 'app-view-project',
  templateUrl: './view-project.component.html',
  styleUrls: ['./view-project.component.css']
})
export class ViewProjectComponent implements OnInit {

  @Input('projectinfo') projectObj:Project;
  @Output() notifyProjectDetail:EventEmitter<Project>=new EventEmitter<Project>();
  projectDetail:Project=new Project();

  constructor() { }

  ngOnInit() {
    this.projectDetail.projectName=this.projectObj.projectName;
    this.projectDetail.priority=this.projectObj.priority;
    this.projectDetail.startDate=this.projectObj.startDate;
    this.projectDetail.endDate=this.projectObj.endDate;
    this.projectDetail.noOfTasks=this.projectObj.noOfTasks;
    this.projectDetail.completedTaskCount=this.projectObj.completedTaskCount;
  }

  updateProject(){
    this.notifyProjectDetail.emit(this.projectDetail);
  }

}
