export class Project {
    projectId: string ;
    projectName: string = '';
    priority: string = '';
    startDate: string = '';
    endDate: string = '';
    userId: string = '';
    status: string = '';
    noOfTasks:number=0;
    completedTaskCount=0;

    constructor() { 

    }
}
