import { Component, OnInit } from '@angular/core';
import { Project } from '../models/project';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  viewProjectResponse:any=this.getAllProjects();
  projectList:Project[];

  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  private getAllProjects(){
    console.log("getAllProjects");
    let obs = this.http.get('http://localhost:8080/projmanager/project/view/all');
    obs.subscribe(responseV=>{
      this.viewProjectResponse=responseV;
      this.projectList = this.viewProjectResponse.projectList;
      console.log("Project List: " +this.projectList);
      console.log("First Project Name:: " +this.viewProjectResponse.projectList[1].projetName);
      
    }); 
  }

  private sortProjectList(criteria:string){
    console.log("sortProjectList: ");
    if(criteria=="SDATE"){
      this.projectList=this.projectList.sort((one, two) => (one.startDate > two.startDate ? 1 : -1));
    }else if(criteria=="EDATE"){
      this.projectList=this.projectList.sort((one, two) => (one.endDate > two.endDate ? 1 : -1));
    }else if(criteria=="PRIO"){
      this.projectList=this.projectList.sort((one, two) => (one.priority > two.priority ? 1 : -1));
    }else if(criteria=="COMP"){
      this.projectList=this.projectList.sort((one, two) => (one.completedTaskCount > two.completedTaskCount ? 1 : -1));
    }
  }

}
