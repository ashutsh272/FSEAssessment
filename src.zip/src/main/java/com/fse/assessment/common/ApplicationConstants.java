package com.fse.assessment.common;

public class ApplicationConstants {

	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_ERROR = "ERROR";
	
	public static final String STATUS_ERROR = "SYS001";
}
