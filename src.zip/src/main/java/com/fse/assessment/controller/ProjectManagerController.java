package com.fse.assessment.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fse.assessment.entity.FSEUser;
import com.fse.assessment.model.FSEUserModel;
import com.fse.assessment.repo.FSEUserRepo;


@RestController // Helps Spring know that this is a rest controller and hence
				// while scanning registers the mappings
public class UserController {

	@Autowired
	FSEUserRepo fseUserRepo;

	@RequestMapping("projmanager/hello")
	public String sayHello() {
		return "Hello from FSE Task Manager!!";
	}

	//view all
	@RequestMapping("projmanager/user/view/all")
	public List<FSEUser> getAllUsers() {
		System.out.println("Request Received for getAllUsers");
		List<FSEUser> resultList = new ArrayList<FSEUser>();
		fseUserRepo.findAll().forEach(user->resultList.add(user));
		return resultList;
	}

	
	//delete
	@RequestMapping("projmanager/user/delete/{userId}")
	public String deleteUser(@PathVariable String userId) {
		System.out.println("Request Received for deleteUser");
		fseUserRepo.delete(Long.valueOf(userId));
		return "User Deleted";
	}

	//Add
	@RequestMapping(method = RequestMethod.POST, value = "projmanager/user/add")
	public String addUser(@RequestBody FSEUser user) {
		System.out.println("Request received for addUser");
		fseUserRepo.save(user);
		return "New User Added";
	}
	
	//Update
	@RequestMapping(method = RequestMethod.POST, value = "projmanager/user/update")
	public String updateUser(@RequestBody FSEUserModel user) {
		System.out.println("Request received for updateUser");
		FSEUser fseUser = fseUserRepo.findOne(Long.valueOf(user.getUserId()));
		if(fseUser==null){
			return "No User Found";
		}else{
			fseUser.setEmployeeId(user.getEmployeeId());
			fseUser.setFirstName(user.getFirstName());
			fseUser.setFirstName(user.getLastName());
			fseUserRepo.save(fseUser);
		}
		
		return "Existing User Updated";
	}

}
