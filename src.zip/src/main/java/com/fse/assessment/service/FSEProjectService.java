package com.fse.assessment.service;

import com.fse.assessment.entity.FSEProject;
import com.fse.assessment.model.BaseResponse;
import com.fse.assessment.service.response.ViewAllProjectsResponse;

public interface FSEProjectService {

	ViewAllProjectsResponse getAllProjects();

	BaseResponse deleteProject(String projectId);

	BaseResponse addProject(FSEProject project);

	BaseResponse updateProject(FSEProject project);

}
